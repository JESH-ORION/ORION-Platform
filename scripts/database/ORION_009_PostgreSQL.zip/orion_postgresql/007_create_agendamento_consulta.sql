CREATE TABLE agendamento (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    paciente_id uuid NOT NULL,
    prestador_id uuid NOT NULL,
    empresa_id uuid NOT NULL,
    servico_id uuid NOT NULL,
    data_inicio timestamptz NOT NULL,
    data_fim timestamptz NOT NULL,
    modalidade varchar(30) NOT NULL,
    status varchar(30) NOT NULL DEFAULT 'AGENDADO',
    observacao text,
    data_criacao timestamptz NOT NULL DEFAULT now(),
    data_atualizacao timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT fk_agendamento_paciente FOREIGN KEY (paciente_id) REFERENCES paciente(id) ON DELETE RESTRICT,
    CONSTRAINT fk_agendamento_prestador_empresa FOREIGN KEY (prestador_id, empresa_id) REFERENCES empresa_usuario(id, empresa_id) ON DELETE RESTRICT,
    CONSTRAINT fk_agendamento_servico_empresa FOREIGN KEY (servico_id, empresa_id) REFERENCES servico(id, empresa_id) ON DELETE RESTRICT,
    CONSTRAINT ck_agendamento_periodo CHECK (data_fim > data_inicio),
    CONSTRAINT ck_agendamento_modalidade CHECK (modalidade IN ('ONLINE','PRESENCIAL')),
    CONSTRAINT ck_agendamento_status CHECK (status IN ('AGENDADO','CONFIRMADO','EM_ANDAMENTO','CANCELADO','CONCLUIDO','NAO_COMPARECEU')),
    CONSTRAINT excl_agendamento_prestador_horario EXCLUDE USING gist (prestador_id WITH =, tstzrange(data_inicio,data_fim,'[)') WITH &&) WHERE (status IN ('AGENDADO','CONFIRMADO','EM_ANDAMENTO'))
);

CREATE INDEX ix_agendamento_paciente_data ON agendamento(paciente_id,data_inicio);
CREATE INDEX ix_agendamento_empresa_data ON agendamento(empresa_id,data_inicio);
CREATE INDEX ix_agendamento_prestador_data ON agendamento(prestador_id,data_inicio);

CREATE TABLE consulta (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    agendamento_id uuid NOT NULL UNIQUE,
    paciente_id uuid NOT NULL,
    profissional_id uuid NOT NULL,
    empresa_id uuid,
    modalidade varchar(30) NOT NULL,
    status varchar(30) NOT NULL DEFAULT 'INICIADA',
    inicio timestamptz,
    fim timestamptz,
    observacao text,
    data_criacao timestamptz NOT NULL DEFAULT now(),
    data_atualizacao timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT fk_consulta_agendamento FOREIGN KEY (agendamento_id) REFERENCES agendamento(id) ON DELETE RESTRICT,
    CONSTRAINT fk_consulta_paciente FOREIGN KEY (paciente_id) REFERENCES paciente(id) ON DELETE RESTRICT,
    CONSTRAINT fk_consulta_profissional FOREIGN KEY (profissional_id) REFERENCES profissional(id) ON DELETE RESTRICT,
    CONSTRAINT fk_consulta_empresa FOREIGN KEY (empresa_id) REFERENCES empresa(id) ON DELETE RESTRICT,
    CONSTRAINT ck_consulta_modalidade CHECK (modalidade IN ('ONLINE','PRESENCIAL')),
    CONSTRAINT ck_consulta_status CHECK (status IN ('INICIADA','EM_ANDAMENTO','FINALIZADA','CANCELADA')),
    CONSTRAINT ck_consulta_periodo CHECK (fim IS NULL OR inicio IS NULL OR fim >= inicio)
);

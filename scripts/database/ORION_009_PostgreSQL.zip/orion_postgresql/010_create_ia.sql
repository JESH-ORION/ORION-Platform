CREATE TABLE agente (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    nome varchar(150) NOT NULL,
    identificador varchar(100) NOT NULL,
    versao varchar(30) NOT NULL,
    finalidade text,
    status varchar(30) NOT NULL DEFAULT 'ATIVO',
    data_criacao timestamptz NOT NULL DEFAULT now(),
    data_atualizacao timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT uq_agente_identificador_versao UNIQUE (identificador,versao),
    CONSTRAINT ck_agente_status CHECK (status IN ('ATIVO','INATIVO'))
);

CREATE TABLE interacao_ia (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    agente_id uuid NOT NULL,
    usuario_id uuid,
    paciente_id uuid,
    conversa_id uuid,
    data_inicio timestamptz NOT NULL DEFAULT now(),
    data_fim timestamptz,
    status varchar(30) NOT NULL DEFAULT 'INICIADA',
    modelo varchar(100),
    versao_agente varchar(30),
    FOREIGN KEY (agente_id) REFERENCES agente(id) ON DELETE RESTRICT,
    FOREIGN KEY (usuario_id) REFERENCES usuario(id) ON DELETE RESTRICT,
    FOREIGN KEY (paciente_id) REFERENCES paciente(id) ON DELETE RESTRICT,
    FOREIGN KEY (conversa_id) REFERENCES conversa(id) ON DELETE RESTRICT,
    CONSTRAINT ck_interacao_ia_status CHECK (status IN ('INICIADA','EM_ANDAMENTO','FINALIZADA','ERRO','CANCELADA')),
    CONSTRAINT ck_interacao_ia_periodo CHECK (data_fim IS NULL OR data_fim >= data_inicio)
);

CREATE TABLE ferramenta_ia (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    nome varchar(150) NOT NULL,
    identificador varchar(100) NOT NULL UNIQUE,
    descricao text,
    status varchar(30) NOT NULL DEFAULT 'ATIVO',
    data_criacao timestamptz NOT NULL DEFAULT now(),
    data_atualizacao timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT ck_ferramenta_ia_status CHECK (status IN ('ATIVO','INATIVO'))
);

CREATE TABLE execucao_ferramenta (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    interacao_ia_id uuid NOT NULL,
    ferramenta_id uuid NOT NULL,
    status varchar(30) NOT NULL DEFAULT 'INICIADA',
    inicio timestamptz NOT NULL DEFAULT now(),
    fim timestamptz,
    erro text,
    FOREIGN KEY (interacao_ia_id) REFERENCES interacao_ia(id) ON DELETE RESTRICT,
    FOREIGN KEY (ferramenta_id) REFERENCES ferramenta_ia(id) ON DELETE RESTRICT,
    CONSTRAINT ck_execucao_ferramenta_status CHECK (status IN ('INICIADA','CONCLUIDA','ERRO','CANCELADA')),
    CONSTRAINT ck_execucao_ferramenta_periodo CHECK (fim IS NULL OR fim >= inicio)
);

INSERT INTO perfil (nome,descricao) VALUES
('ADMIN','Acesso administrativo da plataforma'),
('PROFISSIONAL','Acesso destinado a profissionais de saúde'),
('PACIENTE','Acesso destinado a pacientes')
ON CONFLICT (nome) DO NOTHING;

INSERT INTO metodo_pagamento (nome) VALUES
('PIX'),('CARTAO_CREDITO'),('CARTAO_DEBITO'),('BOLETO'),('DINHEIRO')
ON CONFLICT (nome) DO NOTHING;

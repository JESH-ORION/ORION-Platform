CREATE TABLE arquivo (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    nome_original varchar(255) NOT NULL,
    storage_key text NOT NULL UNIQUE,
    content_type varchar(150) NOT NULL,
    tamanho_bytes bigint NOT NULL CHECK (tamanho_bytes >= 0),
    hash varchar(128),
    categoria varchar(50) NOT NULL,
    status varchar(30) NOT NULL DEFAULT 'ATIVO',
    data_upload timestamptz NOT NULL DEFAULT now(),
    data_criacao timestamptz NOT NULL DEFAULT now(),
    data_atualizacao timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT ck_arquivo_status CHECK (status IN ('ATIVO','INATIVO'))
);

CREATE TABLE exame_arquivo (
    exame_id uuid NOT NULL,
    arquivo_id uuid NOT NULL,
    tipo varchar(50),
    data_criacao timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (exame_id,arquivo_id),
    FOREIGN KEY (exame_id) REFERENCES exame(id) ON DELETE RESTRICT,
    FOREIGN KEY (arquivo_id) REFERENCES arquivo(id) ON DELETE RESTRICT
);

CREATE TABLE conversa (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tipo varchar(40) NOT NULL,
    paciente_id uuid,
    profissional_id uuid,
    status varchar(30) NOT NULL DEFAULT 'ATIVA',
    data_criacao timestamptz NOT NULL DEFAULT now(),
    data_atualizacao timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (paciente_id) REFERENCES paciente(id) ON DELETE RESTRICT,
    FOREIGN KEY (profissional_id) REFERENCES profissional(id) ON DELETE RESTRICT,
    CONSTRAINT ck_conversa_status CHECK (status IN ('ATIVA','ENCERRADA','ARQUIVADA'))
);

CREATE TABLE mensagem (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    conversa_id uuid NOT NULL,
    usuario_id uuid,
    conteudo text NOT NULL,
    tipo varchar(30) NOT NULL,
    data_envio timestamptz NOT NULL DEFAULT now(),
    lida_em timestamptz,
    FOREIGN KEY (conversa_id) REFERENCES conversa(id) ON DELETE RESTRICT,
    FOREIGN KEY (usuario_id) REFERENCES usuario(id) ON DELETE RESTRICT
);

CREATE INDEX ix_mensagem_conversa_data ON mensagem(conversa_id,data_envio);

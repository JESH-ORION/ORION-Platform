CREATE TABLE permissao (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    nome varchar(150) NOT NULL,
    identificador varchar(150) NOT NULL UNIQUE,
    descricao text,
    data_criacao timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE perfil_permissao (
    perfil_id uuid NOT NULL,
    permissao_id uuid NOT NULL,
    PRIMARY KEY (perfil_id,permissao_id),
    FOREIGN KEY (perfil_id) REFERENCES perfil(id) ON DELETE RESTRICT,
    FOREIGN KEY (permissao_id) REFERENCES permissao(id) ON DELETE RESTRICT
);

CREATE TABLE auditoria (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    usuario_id uuid,
    acao varchar(100) NOT NULL,
    entidade varchar(100) NOT NULL,
    entidade_id uuid,
    data_evento timestamptz NOT NULL DEFAULT now(),
    ip inet,
    sucesso boolean NOT NULL DEFAULT true,
    FOREIGN KEY (usuario_id) REFERENCES usuario(id) ON DELETE RESTRICT
);

CREATE INDEX ix_auditoria_entidade ON auditoria(entidade,entidade_id);
CREATE INDEX ix_auditoria_data ON auditoria(data_evento);

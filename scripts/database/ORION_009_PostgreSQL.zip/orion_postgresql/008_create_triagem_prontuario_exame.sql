CREATE TABLE triagem (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    paciente_id uuid NOT NULL,
    consulta_id uuid,
    origem varchar(30) NOT NULL,
    status varchar(30) NOT NULL DEFAULT 'INICIADA',
    resumo text,
    classificacao varchar(50),
    data_criacao timestamptz NOT NULL DEFAULT now(),
    data_atualizacao timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (paciente_id) REFERENCES paciente(id) ON DELETE RESTRICT,
    FOREIGN KEY (consulta_id) REFERENCES consulta(id) ON DELETE RESTRICT,
    CONSTRAINT ck_triagem_origem CHECK (origem IN ('IA','PROFISSIONAL','MANUAL')),
    CONSTRAINT ck_triagem_status CHECK (status IN ('INICIADA','EM_ANDAMENTO','FINALIZADA','CANCELADA'))
);

CREATE TABLE prontuario (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    paciente_id uuid NOT NULL UNIQUE,
    status varchar(30) NOT NULL DEFAULT 'ATIVO',
    data_criacao timestamptz NOT NULL DEFAULT now(),
    data_atualizacao timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (paciente_id) REFERENCES paciente(id) ON DELETE RESTRICT,
    CONSTRAINT ck_prontuario_status CHECK (status IN ('ATIVO','INATIVO'))
);

CREATE TABLE exame (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    paciente_id uuid NOT NULL,
    profissional_id uuid,
    consulta_id uuid,
    organizacao_id uuid,
    tipo varchar(150) NOT NULL,
    status varchar(30) NOT NULL DEFAULT 'SOLICITADO',
    data_solicitacao timestamptz NOT NULL DEFAULT now(),
    data_realizacao timestamptz,
    resultado_resumo text,
    data_criacao timestamptz NOT NULL DEFAULT now(),
    data_atualizacao timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (paciente_id) REFERENCES paciente(id) ON DELETE RESTRICT,
    FOREIGN KEY (profissional_id) REFERENCES profissional(id) ON DELETE RESTRICT,
    FOREIGN KEY (consulta_id) REFERENCES consulta(id) ON DELETE RESTRICT,
    FOREIGN KEY (organizacao_id) REFERENCES organizacao(id) ON DELETE RESTRICT,
    CONSTRAINT ck_exame_status CHECK (status IN ('SOLICITADO','AGENDADO','REALIZADO','RESULTADO_DISPONIVEL','CANCELADO'))
);

CREATE INDEX ix_exame_paciente_data ON exame(paciente_id,data_realizacao);

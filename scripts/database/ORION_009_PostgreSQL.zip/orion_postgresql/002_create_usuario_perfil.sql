CREATE TABLE perfil (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    nome varchar(100) NOT NULL,
    descricao text,
    status varchar(30) NOT NULL DEFAULT 'ATIVO',
    data_criacao timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT uq_perfil_nome UNIQUE (nome),
    CONSTRAINT ck_perfil_status CHECK (status IN ('ATIVO','INATIVO'))
);

CREATE TABLE usuario (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    perfil_id uuid NOT NULL,
    nome varchar(150) NOT NULL,
    email varchar(254) NOT NULL,
    telefone varchar(30),
    senha_hash text NOT NULL,
    documento varchar(20),
    tipo_documento varchar(10),
    status varchar(30) NOT NULL DEFAULT 'ATIVO',
    ultimo_acesso timestamptz,
    data_criacao timestamptz NOT NULL DEFAULT now(),
    data_atualizacao timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT uq_usuario_email UNIQUE (email),
    CONSTRAINT uq_usuario_documento UNIQUE (documento),
    CONSTRAINT fk_usuario_perfil FOREIGN KEY (perfil_id) REFERENCES perfil(id) ON DELETE RESTRICT,
    CONSTRAINT ck_usuario_status CHECK (status IN ('ATIVO','INATIVO','BLOQUEADO')),
    CONSTRAINT ck_usuario_tipo_documento CHECK (tipo_documento IS NULL OR tipo_documento IN ('CPF','CNPJ'))
);

CREATE INDEX ix_usuario_status ON usuario(status);

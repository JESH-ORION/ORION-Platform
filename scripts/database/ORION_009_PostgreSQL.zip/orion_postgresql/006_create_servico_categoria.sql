CREATE TABLE categoria (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    nome varchar(100) NOT NULL,
    descricao text,
    status varchar(30) NOT NULL DEFAULT 'ATIVO',
    data_criacao timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT uq_categoria_nome UNIQUE (nome),
    CONSTRAINT ck_categoria_status CHECK (status IN ('ATIVO','INATIVO'))
);

CREATE TABLE servico (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    empresa_id uuid NOT NULL,
    categoria_id uuid NOT NULL,
    nome varchar(120) NOT NULL,
    descricao text,
    preco numeric(12,2) NOT NULL DEFAULT 0 CHECK (preco >= 0),
    duracao_minutos integer NOT NULL CHECK (duracao_minutos > 0),
    modalidade varchar(30) NOT NULL DEFAULT 'ONLINE',
    status varchar(30) NOT NULL DEFAULT 'ATIVO',
    data_criacao timestamptz NOT NULL DEFAULT now(),
    data_atualizacao timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT uq_servico_empresa_id UNIQUE (id, empresa_id),
    CONSTRAINT fk_servico_empresa FOREIGN KEY (empresa_id) REFERENCES empresa(id) ON DELETE RESTRICT,
    CONSTRAINT fk_servico_categoria FOREIGN KEY (categoria_id) REFERENCES categoria(id) ON DELETE RESTRICT,
    CONSTRAINT ck_servico_modalidade CHECK (modalidade IN ('ONLINE','PRESENCIAL','AMBAS')),
    CONSTRAINT ck_servico_status CHECK (status IN ('ATIVO','INATIVO'))
);

CREATE INDEX ix_servico_empresa ON servico(empresa_id);

CREATE OR REPLACE FUNCTION fn_atualizar_data_atualizacao()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
    NEW.data_atualizacao = now();
    RETURN NEW;
END;
$$;

-- Triggers explícitas apenas nas entidades com data_atualizacao.
DO $$
DECLARE
    tabela text;
BEGIN
    FOREACH tabela IN ARRAY ARRAY['usuario','paciente','profissional','especialidade','organizacao','empresa','servico','agendamento','consulta','triagem','prontuario','exame','arquivo','conversa','agente','interacao_ia','ferramenta_ia','pagamento']
    LOOP
        EXECUTE format('CREATE TRIGGER trg_%I_updated_at BEFORE UPDATE ON %I FOR EACH ROW EXECUTE FUNCTION fn_atualizar_data_atualizacao()', tabela, tabela);
    END LOOP;
END $$;

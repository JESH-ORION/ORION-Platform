CREATE TABLE paciente (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    usuario_id uuid NOT NULL,
    nome_completo varchar(200) NOT NULL,
    data_nascimento date,
    sexo varchar(30),
    cpf varchar(14),
    status varchar(30) NOT NULL DEFAULT 'ATIVO',
    data_criacao timestamptz NOT NULL DEFAULT now(),
    data_atualizacao timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT uq_paciente_usuario UNIQUE (usuario_id),
    CONSTRAINT uq_paciente_cpf UNIQUE (cpf),
    CONSTRAINT fk_paciente_usuario FOREIGN KEY (usuario_id) REFERENCES usuario(id) ON DELETE RESTRICT,
    CONSTRAINT ck_paciente_status CHECK (status IN ('ATIVO','INATIVO'))
);

CREATE TABLE profissional (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    usuario_id uuid NOT NULL,
    registro_profissional varchar(50) NOT NULL,
    conselho varchar(50) NOT NULL,
    uf_conselho varchar(2) NOT NULL,
    status varchar(30) NOT NULL DEFAULT 'ATIVO',
    data_criacao timestamptz NOT NULL DEFAULT now(),
    data_atualizacao timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT uq_profissional_usuario UNIQUE (usuario_id),
    CONSTRAINT uq_profissional_registro UNIQUE (conselho, registro_profissional, uf_conselho),
    CONSTRAINT fk_profissional_usuario FOREIGN KEY (usuario_id) REFERENCES usuario(id) ON DELETE RESTRICT,
    CONSTRAINT ck_profissional_status CHECK (status IN ('ATIVO','INATIVO','BLOQUEADO'))
);

CREATE INDEX ix_profissional_registro ON profissional(registro_profissional);

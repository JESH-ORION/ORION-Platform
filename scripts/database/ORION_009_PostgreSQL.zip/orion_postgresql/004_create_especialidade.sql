CREATE TABLE especialidade (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    nome varchar(150) NOT NULL,
    descricao text,
    status varchar(30) NOT NULL DEFAULT 'ATIVO',
    data_criacao timestamptz NOT NULL DEFAULT now(),
    data_atualizacao timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT uq_especialidade_nome UNIQUE (nome),
    CONSTRAINT ck_especialidade_status CHECK (status IN ('ATIVO','INATIVO'))
);

CREATE TABLE profissional_especialidade (
    profissional_id uuid NOT NULL,
    especialidade_id uuid NOT NULL,
    data_criacao timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (profissional_id, especialidade_id),
    FOREIGN KEY (profissional_id) REFERENCES profissional(id) ON DELETE RESTRICT,
    FOREIGN KEY (especialidade_id) REFERENCES especialidade(id) ON DELETE RESTRICT
);

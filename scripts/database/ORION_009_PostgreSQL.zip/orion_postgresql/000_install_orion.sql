-- ORION 009 - INSTALAÇÃO COMPLETA
-- Execute este arquivo em um banco de desenvolvimento vazio.
-- Ele usa apenas PostgreSQL + pgcrypto + btree_gist.

BEGIN;
\i 001_enable_extensions.sql
\i 002_create_usuario_perfil.sql
\i 003_create_paciente_profissional.sql
\i 004_create_especialidade.sql
\i 005_create_organizacao_empresa.sql
\i 006_create_servico_categoria.sql
\i 007_create_agendamento_consulta.sql
\i 008_create_triagem_prontuario_exame.sql
\i 009_create_arquivo_conversa.sql
\i 010_create_ia.sql
\i 011_create_pagamento_avaliacao.sql
\i 012_create_seguranca_auditoria.sql
\i 013_create_updated_at.sql
\i 014_seed_inicial.sql
COMMIT;

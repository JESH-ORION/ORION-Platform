CREATE TABLE metodo_pagamento (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    nome varchar(50) NOT NULL UNIQUE,
    status varchar(30) NOT NULL DEFAULT 'ATIVO',
    data_criacao timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT ck_metodo_pagamento_status CHECK (status IN ('ATIVO','INATIVO'))
);

CREATE TABLE pagamento (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    agendamento_id uuid NOT NULL,
    metodo_pagamento_id uuid NOT NULL,
    valor numeric(12,2) NOT NULL CHECK (valor >= 0),
    status varchar(30) NOT NULL DEFAULT 'PENDENTE',
    data_pagamento timestamptz,
    transacao_externa_id varchar(255),
    data_criacao timestamptz NOT NULL DEFAULT now(),
    data_atualizacao timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (agendamento_id) REFERENCES agendamento(id) ON DELETE RESTRICT,
    FOREIGN KEY (metodo_pagamento_id) REFERENCES metodo_pagamento(id) ON DELETE RESTRICT,
    CONSTRAINT ck_pagamento_status CHECK (status IN ('PENDENTE','PAGO','REEMBOLSADO','FALHOU'))
);

CREATE INDEX ix_pagamento_agendamento ON pagamento(agendamento_id);
CREATE INDEX ix_pagamento_status ON pagamento(status);

CREATE TABLE avaliacao (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    agendamento_id uuid NOT NULL UNIQUE,
    nota integer NOT NULL CHECK (nota BETWEEN 1 AND 5),
    comentario text,
    data_criacao timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (agendamento_id) REFERENCES agendamento(id) ON DELETE RESTRICT
);

CREATE TABLE organizacao (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    nome varchar(200) NOT NULL,
    nome_fantasia varchar(200),
    tipo varchar(50) NOT NULL,
    documento varchar(30),
    status varchar(30) NOT NULL DEFAULT 'ATIVO',
    data_criacao timestamptz NOT NULL DEFAULT now(),
    data_atualizacao timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT uq_organizacao_documento UNIQUE (documento),
    CONSTRAINT ck_organizacao_status CHECK (status IN ('ATIVO','INATIVO')),
    CONSTRAINT ck_organizacao_tipo CHECK (tipo IN ('CLINICA','HOSPITAL','LABORATORIO','EMPRESA','GRUPO_PROFISSIONAL'))
);

-- Compatibilidade semântica com o modelo anterior: empresa é a organização comercial.
CREATE TABLE empresa (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    organizacao_id uuid UNIQUE,
    id_proprietario uuid NOT NULL,
    razao_social varchar(150) NOT NULL,
    nome_fantasia varchar(150),
    cnpj varchar(20),
    telefone varchar(30),
    endereco text,
    status varchar(30) NOT NULL DEFAULT 'ATIVO',
    data_criacao timestamptz NOT NULL DEFAULT now(),
    data_atualizacao timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT uq_empresa_cnpj UNIQUE (cnpj),
    CONSTRAINT fk_empresa_organizacao FOREIGN KEY (organizacao_id) REFERENCES organizacao(id) ON DELETE RESTRICT,
    CONSTRAINT fk_empresa_proprietario FOREIGN KEY (id_proprietario) REFERENCES usuario(id) ON DELETE RESTRICT,
    CONSTRAINT ck_empresa_status CHECK (status IN ('ATIVO','INATIVO'))
);

CREATE TABLE empresa_usuario (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    empresa_id uuid NOT NULL,
    usuario_id uuid NOT NULL,
    profissional_id uuid,
    cargo_funcao varchar(100),
    ativo boolean NOT NULL DEFAULT true,
    data_criacao timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT uq_empresa_usuario UNIQUE (empresa_id, usuario_id),
    CONSTRAINT uq_empresa_usuario_id_empresa UNIQUE (id, empresa_id),
    CONSTRAINT fk_eu_empresa FOREIGN KEY (empresa_id) REFERENCES empresa(id) ON DELETE RESTRICT,
    CONSTRAINT fk_eu_usuario FOREIGN KEY (usuario_id) REFERENCES usuario(id) ON DELETE RESTRICT,
    CONSTRAINT fk_eu_profissional FOREIGN KEY (profissional_id) REFERENCES profissional(id) ON DELETE RESTRICT,
    CONSTRAINT uq_empresa_profissional UNIQUE (empresa_id, profissional_id)
);

CREATE INDEX ix_empresa_usuario_usuario ON empresa_usuario(usuario_id);
